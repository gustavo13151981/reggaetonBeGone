.. Development chapter frontpage

Development
===========

This chapter explains how to write Quark's code and how to contribute.

.. toctree::

    dev
    coding_style
