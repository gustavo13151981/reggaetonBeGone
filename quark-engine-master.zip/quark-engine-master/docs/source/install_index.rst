.. Installation chapter frontpage

Installation
============

This chapter explains how to write Quark's code and how to contribute.

.. toctree::

    install
    testing

