quark.webreport package
=======================

Submodules
----------

quark.webreport.generate module
-------------------------------

.. automodule:: quark.webreport.generate
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: quark.webreport
   :members:
   :undoc-members:
   :show-inheritance:
