+++++++++++++++++
Quark MIT Program
+++++++++++++++++

Quark MIT aims to create a **WIN-WIN** for both new comers and the community. 

For new comers, the community helps you to build a stronger resume 
by creating specific works that fit the job description of your **DREAM JOB**.

| For the community, Quark-Engine gets new energy by the work the new comers contribute. 
| And the most important of all, the Quark community gets to **GROW**.

- **Find more details below:**

.. image:: https://i.imgur.com/XNwGYEN.png

Quark to You
-------------

We help our MIT program members to build stronger resumes upon Quark-Engine in just **5** specific steps.

.. image:: https://i.imgur.com/1Qlf03U.png

You to Quark
-------------

Alunies are expected to positive feedbacks and continously participation of the Quark Community (not mandatory).

.. image:: https://i.imgur.com/xknY1Jc.png

Better Community
-----------------

We believe helping people is the key to build a better community.

.. image:: https://i.imgur.com/kIJBqOn.png

Minimum Requirements
---------------------

Members need to complete at least **1** goal every **6** months.

.. image:: https://i.imgur.com/LxAVUcE.png

Contact us
----------

Send a direct message to our Twitter @quarkengine to join this program!

.. image:: https://i.imgur.com/762fgld.png