bwapidata
----------------

This is used to compile SparCraft in a linux environment without having to worry about reconfiguring BWAPI

This is a stripped-down version of BWAPI which contains only headers and .cpp files, without BWTA

Used with permission from Adam Heinermann of the BWAPI project:

https://code.google.com/p/bwapi/