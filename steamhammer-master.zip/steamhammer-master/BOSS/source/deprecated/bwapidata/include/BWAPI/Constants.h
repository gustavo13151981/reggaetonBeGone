#pragma once
namespace BWAPI
{
  /** Used for converting between TilePosition coordinates and Position coordinates. */
  #define TILE_SIZE      32
  #define PYLON_X_RADIUS  8
  #define PYLON_Y_RADIUS  5
}
