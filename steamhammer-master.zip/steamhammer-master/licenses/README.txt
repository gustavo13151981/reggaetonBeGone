License.md - the original license of UAlbertaBot, which Steamhammer is a fork of
LICENSE - license for FAP
Steamhammer.txt - license for Steamhammer

All are MIT licenses, which require only that the license file be passed along in copies.